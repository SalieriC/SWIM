//brotheroak#6625
/*****
 * Here's my macro to change the animated token to a dead (static) image via a macro. I don't know how to post code in pretty colours though!
 * The full macro is a dead toggle - it applies a Token Magic FX blood splash and sets the CUB condition to dead, then calls my new function to swap the token image if a dead version is available. If the token is already dead (checked by seeing if the Token Magic FX is already applied) it will reverse the effect. I may change this check to instead check the CUB condition.
 * Macro assumes the normal image could be webm, webp or png and that the dead image is either webp or png and is in the same folder as the original image and named <orig img>_Dead.<ext>
 * https://discord.com/channels/170995199584108546/699750150674972743/905048853068263484
 */

async function fileExists(img) {
    let files;
    let exists = true;
    try { files = await FilePicker.browse('user', img) }
    catch { exists = false }
    return (exists);
}

async function changeImg(token) {
    let dotPos = token.data.img.lastIndexOf(".");
    let deadPos = token.data.img.indexOf("_Dead");
    let newString = "";
    if (deadPos != -1) {
        // current image is a dead one, so need to remove that and change to webm or webp or png
        let foreString = token.data.img.substring(0, deadPos);
        if (await fileExists(foreString + ".webm")) {
            newString = foreString + ".webm";
        } else if (await fileExists(foreString + ".webp")) {
            newString = foreString + ".webp";
        } else if (await fileExists(foreString + ".png")) {
            newString = foreString + ".png";
        }
    } else {
        // Current image is not dead, so add the dead suffix. Assume the dead image is webp or png
        let foreString = token.data.img.substring(0, dotPos);
        if (await fileExists(foreString + "_Dead.webp")) {
            newString = foreString + "_Dead.webp";
        } else if (await fileExists(foreString + "_Dead.png")) {
            newString = foreString + "_Dead.png";
        }
    }
    if (newString != "") {
        token.update({ "img": newString });
    }
}

async function deadFunction() {

    let params =
        [{
            filterType: "splash",
            filterId: "dead",
            color: 0x900505,
            padding: 30,
            time: Math.random() * 1000,
            seed: Math.random() / 100,
            splashFactor: 2,
            spread: 7,
            blend: 1,
            dimX: 1,
            dimY: 1,
            cut: true,
            textureAlphaBlend: false
        }];

    for (const token of canvas.tokens.controlled) {
        // check if token currently has the dead filter on it (needs to match the filterID name) to see if it is dead or not
        if (token.TMFXhasFilterId("dead")) {
            game.cub.removeCondition("Dead", token);
            await token.TMFXdeleteFilters(params[0]["filterId"]);
        } else {
            // not currently dead, so kill it!
            game.cub.addCondition("Dead", token);
            await token.TMFXaddUpdateFilters(params);
        }
        await changeImg(token);
    }
}

// call the async function
deadFunction();