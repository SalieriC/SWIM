async function playSFX(success) {
    const sfx_success = `Resources%20all%20worlds/Audio/Sound%20Effects/mag/mysticism/soultrap/mag_mysticism_soultrap_capture.ogg`;
    const sfx_failure = `Resources%20all%20worlds/Audio/Sound%20Effects/mag/mysticism/soultrap/mag_mysticism_captureshader.ogg`;
    if (success === true) {
        AudioHelper.play({ src: `${sfx_success}` }, true);
        playVFX();
    }
    else {
        AudioHelper.play({ src: `${sfx_failure}` }, true);
    }
}

async function main() {
    // No Token is Selected
    let tokenTarget = Array.from(game.user.targets)[0];
    if ((!token || canvas.tokens.controlled.length > 1) || tokenTarget === undefined) {
        ui.notifications.error("Please select a single token and target first.");
        return;
    }
    // Collecting all empty Soul Gems
    const actor = token.actor;
    const soul_gems = actor.items.filter(i =>
    (i.type === "gear" &&
        i.data.name.includes("Soul Gem") &&
        i.data.name.includes("empty"))
    );
    //console.log(soul_gems);
    let success = false;
    if (soul_gems.length <= 0) {
        ui.notifications.warn("You are out of empty Soul Gems.");
        playSFX(success);
        return;
    }
    if (!tokenTarget.actor.data.data.additionalStats.soulSize) {
        ui.notifications.warn("Your target has no soul.");
        playSFX(success);
        return;
    }
    const target_SoulSize = tokenTarget.actor.data.data.additionalStats.soulSize.value
    const gem = soul_gems.find((sg) => { return sg.data.name.includes(target_SoulSize) });
    if (!gem || gem.data.data.quantity <= 0) {
        ui.notifications.error("No Soul Gem is big enough to capture this soul.");
        playSFX(success);
        return;
    }
    // run the filling process
    else {
        success = true;
        //Update target:
        await tokenTarget.update({ "data.additionalStats.soulSize.value": `Drained` })

        //Get if there are soul gems of the same size:
        const soul_gems_full = actor.items.filter(i =>
        (i.type === "gear" &&
            i.data.name.includes("Soul Gem") &&
            i.data.name.includes("full"))
        );
        const gem_full = soul_gems_full.find((sg) => { return sg.data.name.includes(target_SoulSize) });

        //defining variables:
        let newAmount_empty;
        let updates;
        let newCharge = gem.data.data.additionalStats.charge.max;

        //Check for stack:
        if (gem.data.data.quantity > 1) { newAmount_empty = gem.data.data.quantity - 1; }
        else { newAmount_empty = 0; }

        // if there is a full one of this size already, discard the empty one and increase the full ones quantity by 1:
        if (/*(newAmount_empty === 0 || newAmount_empty > 0) &&*/ gem_full) {
            updates = [
                { _id: gem.id, "data.quantity": newAmount_empty },
            ];
            await actor.updateOwnedItem({ _id: gem_full.id, "data.quantity": gem_full.data.data.quantity + 1 })
        }
        // If everything else fails, create a new entry by using a template from the world:
        else /*if (newAmount_empty > 0 && !gem_full)*/ {
            updates = [
                { _id: gem.id, "data.quantity": newAmount_empty },
            ];

            let gem_new = game.items.getName(`Soul Gem (${target_SoulSize}), full`);
            if (!gem_new) {
                ui.notifications.error("GM messed up; no Soul Gems in this World.");
                return;
            }
            actor.createOwnedItem(gem_new.data);
        }

        // Updating the Weapon
        playSFX(success);
        // If this was the last empty soul gem, delete it, otherwise update it:
        if (newAmount_empty === 0) { gem.delete(); }
        else { await actor.updateOwnedItem(updates); }
    }
}

async function playVFX() {
    /// This macro pulls from the JB2A list of Magic Missiles to throw 1 random path at targeted tokens

    //folder01 targets the Magic Missile Folder
    let folder01 = "modules/jb2a_patreon/Library/1st_Level/Magic_Missile/";
    //Each file is then defined as a variable that will be stored in an array and then chose at random
    let mmA = `${folder01}MagicMissile_01_Regular_Purple_30ft_01_1600x400.webm`;
    let mmB = `${folder01}MagicMissile_01_Regular_Purple_30ft_02_1600x400.webm`;
    let mmC = `${folder01}MagicMissile_01_Regular_Purple_30ft_03_1600x400.webm`;
    let mmD = `${folder01}MagicMissile_01_Regular_Purple_30ft_04_1600x400.webm`;
    let mmE = `${folder01}MagicMissile_01_Regular_Purple_30ft_05_1600x400.webm`;
    let mmF = `${folder01}MagicMissile_01_Regular_Purple_30ft_06_1600x400.webm`;
    let mmG = `${folder01}MagicMissile_01_Regular_Purple_30ft_07_1600x400.webm`;
    let mmH = `${folder01}MagicMissile_01_Regular_Purple_30ft_08_1600x400.webm`;
    let mmI = `${folder01}MagicMissile_01_Regular_Purple_30ft_09_1600x400.webm`;

    let mmAA = `${folder01}MagicMissile_01_Regular_Purple_60ft_01_2800x400.webm`;
    let mmBB = `${folder01}MagicMissile_01_Regular_Purple_60ft_02_2800x400.webm`;
    let mmCC = `${folder01}MagicMissile_01_Regular_Purple_60ft_03_2800x400.webm`;
    let mmDD = `${folder01}MagicMissile_01_Regular_Purple_60ft_04_2800x400.webm`;
    let mmEE = `${folder01}MagicMissile_01_Regular_Purple_60ft_05_2800x400.webm`;
    let mmFF = `${folder01}MagicMissile_01_Regular_Purple_60ft_06_2800x400.webm`;
    let mmGG = `${folder01}MagicMissile_01_Regular_Purple_60ft_07_2800x400.webm`;
    let mmHH = `${folder01}MagicMissile_01_Regular_Purple_60ft_08_2800x400.webm`;
    let mmII = `${folder01}MagicMissile_01_Regular_Purple_60ft_09_2800x400.webm`;

    ///Check if Module dependencies are installed or returns an error to the user
    if (!canvas.fxmaster) ui.notifications.error("This macro depends on the FXMaster module. Make sure it is installed and enabled");
    if (game.user.targets.size == 0) ui.notifications.error('You must target at least one token');
    if (canvas.tokens.controlled.length == 0) ui.notifications.error("Please select your token");



    function random_itemA(itemsA) {
        return itemsA[Math.floor(Math.random() * itemsA.length)];
    }

    var itemsA = [mmA, mmB, mmC, mmD, mmE, mmF, mmG, mmH, mmI];

    function random_itemB(itemsB) {
        return itemsB[Math.floor(Math.random() * itemsB.length)];
    }

    var itemsB = [mmAA, mmBB, mmCC, mmDD, mmEE, mmFF, mmGG, mmHH, mmII];
    const wait = (delay) => new Promise((resolve) => setTimeout(resolve, delay))

    async function Cast() {
        var myStringArray = Array.from(game.user.targets)[0];
        var arrayLength = game.user.targets.size;
        for (var i = 0; i < arrayLength; i++) {

            let mainTarget = Array.from(game.user.targets)[i];
            let myToken = canvas.tokens.controlled[0];

            let ray = new Ray(mainTarget.center, myToken.center);
            let anDeg = -(ray.angle * 57.3);
            let anDist = ray.distance;

            let anFile = random_itemA(itemsA);
            let anFileSize = 1200;
            let anchorX = 0.125;
            switch (true) {
                case (anDist < 1800):
                    anFileSize = 1200;
                    anFile = random_itemA(itemsA);
                    anchorX = 0.125;
                    break;
                default:
                    anFileSize = 2400;
                    anFile = random_itemB(itemsB);
                    anchorX = 0.071;
                    break;
            }



            let anScale = anDist / anFileSize;
            let anScaleY = anScale;
            if (anDist <= 600) { anScaleY = 0.5 }
            if (anDist > 600 && anDist < 1000) { anScaleY = 0.66 }
            if (anDist >= 1000 && anDist < 1800) { anScaleY = anScale }
            if (anDist >= 1800 && anDist < 2400) { anScaleY = 0.8 }
            if (anDist >= 2400) { anScaleY = anScale }

            let spellAnim =
            {
                file: anFile,
                position: mainTarget.center,
                anchor: {
                    x: anchorX,
                    y: 0.5
                },
                angle: anDeg,
                scale: {
                    x: anScale,
                    y: anScaleY
                }
            };

            canvas.fxmaster.playVideo(spellAnim);
            await wait(80);

            game.socket.emit('module.fxmaster', spellAnim);
            await wait(50);
        }
    }
    Cast()
}

main();