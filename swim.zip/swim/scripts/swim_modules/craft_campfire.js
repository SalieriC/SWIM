/*******************************************
 * Craft Campfire
 * // v.2.0.0
 * By SalieriC#8263
 ******************************************/
import { execute_as_gm } from "../helpers/socket_helper.js"

export async function craft_campfire_script() {
    //Get asset:
    const campfireTextureLit = game.settings.get('swim', 'campfireImgOn')
    //Pick the campfire location:
    // Portal 1.0.7 needs an origin or pick() throws; use the controlled token if there is one.
    // No range limit (the former `.range(1)` would be 1 *scene distance unit* in Portal, i.e. practically unusable with an origin).
    const originToken = canvas.tokens.controlled[0]
    const picked = await new Portal()
        .color("#ff0000")
        .texture(campfireTextureLit)
        .origin(originToken ?? { x: 0, y: 0, elevation: 0 })
        .pick()
    if (!picked) { return } // placement cancelled (right click)

    const data = {
        icon: campfireTextureLit,
        position: {
            x: picked.x,
            y: picked.y,
        },
        scene: {
            _id: game.scenes.current._id
        }
    }
    await execute_as_gm("craftCampfire", data)
    if (game.modules.get('monks-active-tiles')?.active) {
        ui.notifications.notify(game.i18n.localize("SWIM.notification.campfireCreated"))
    }
}

export async function craft_campfire_gm(data) {
    const scene = game.scenes.get(data.scene._id)
    const size = scene.grid.size
    const campfireTextureLit = game.settings.get('swim', 'campfireImgOn')

    //Create Light:
    const lightData = {
        "x": data.position.x,
        "y": data.position.y,
        "rotation": 0,
        "walls": true,
        "vision": false,
        "config": {
            "alpha": 0.4,
            "angle": 360,
            "bright": 4,
            "color": "#C98A76",
            "coloration": 1,
            "dim": 4.5,
            "attenuation": 0.5,
            "luminosity": 0.5,
            "saturation": 0,
            "contrast": 0,
            "shadows": 0,
            "animation": {
                "type": "torch",
                "speed": 5,
                "intensity": 6,
                "reverse": false
            },
            "darkness": {
                "min": 0,
                "max": 1
            }
        },
        "hidden": false,
    }
    const lights = await scene.createEmbeddedDocuments("AmbientLight", [lightData])
    const light = lights[0]

    //Create Light:
    const soundData = {
        "path": "modules/swim/assets/sfx/Campfire-sound-altered-Alexander-www.orangefreesounds.com.ogg.ogg",
        "x": data.position.x,
        "y": data.position.y,
        "radius": 4.5,
        "easing": true,
        "walls": true,
        "volume": 0.75,
        "darkness": {
            "min": 0,
            "max": 1
        },
        "repeat": false,
        "hidden": false
    }
    const sounds = await scene.createEmbeddedDocuments("AmbientSound", [soundData])
    const sound = sounds[0]

    //Create Tile:
    //Flags for Monks Active Tile Triggers:
    const mattFlags = {
        "active": true,
        "record": false,
        "restriction": "all",
        "controlled": "all",
        "trigger": [
            "",
            "dblclick"
        ],
        "allowpaused": false,
        "usealpha": true,
        "pointer": true,
        "pertoken": false,
        "minrequired": 0,
        "chance": 100,
        "fileindex": 0,
        "actions": [
            {
                "action": "playsound",
                "data": {
                    "audiofile": "modules/swim/assets/sfx/Fireball-Super-Quick-Whoosh-www.fesliyanstudios.com.ogg",
                    "audiofor": "all",
                    "volume": 1,
                    "loop": false,
                    "fade": 0,
                    "scenerestrict": true,
                    "prevent": false
                },
                "id": foundry.utils.randomID(16)
            },
            {
                "action": "delete",
                "data": {
                    "entity": {
                        "id": "tile",
                        "name": "This Tile"
                    },
                    "collection": "tiles"
                },
                "id": foundry.utils.randomID(16)
            },
            {
                "action": "delete",
                "data": {
                    "entity": {
                        "id": `Scene.${data.scene._id}.AmbientLight.${light._id}`,
                        "name": `AmbientLight: ${light._id}`
                    },
                    "collection": "tiles"
                },
                "id": foundry.utils.randomID(16)
            },
            {
                "action": "delete",
                "data": {
                    "entity": {
                        "id": `Scene.${data.scene._id}.AmbientSound.${sound._id}`,
                        "name": `AmbientSound: ${sound._id}`
                    },
                    "collection": "tiles"
                },
                "id": foundry.utils.randomID(16)
            }
        ],
        "files": []
    }

    const tileData = {
        "texture": {
            "src": campfireTextureLit,
            "scaleX": 1,
            "scaleY": 1,
            "offsetX": 0,
            "offsetY": 0,
            "anchorX": 0, //v14: tile textures are centre anchored by default, x/y below are the top left corner
            "anchorY": 0,
            "rotation": Math.floor(Math.random() * (360 - 0 + 1) + 0), //random rotation
            "tint": null
        },
        "x": Math.round(data.position.x - (size / 2)), //need to subtract half the grid size as the tile placement is measured from the top left instead of center.
        "y": Math.round(data.position.y - (size / 2)),
        "width": size,
        "height": size,
        "sort": 100,
        "rotation": Math.floor(Math.random() * (360 - 0 + 1) + 0), //random rotation,
        "alpha": 1,
        "hidden": false,
        "locked": false,
        "occlusion": {
            "modes": [],
            "alpha": 0
        },
        "video": {
            "loop": true,
            "autoplay": true,
            "volume": 0
        },
        "flags": {
            "monks-active-tiles": mattFlags
        }
    }
    const tiles = await scene.createEmbeddedDocuments("Tile", [tileData])
    const tile = tiles[0]    
    if (tile) {
        const volume = game.settings.get('swim', 'defaultVolume')
        await swim.play_sfx("modules/swim/assets/sfx/Fireball-Super-Quick-Whoosh-www.fesliyanstudios.com.ogg", volume, true)
        if (!game.modules.get('monks-active-tiles')?.active) {
            ui.notifications.warn(game.i18n.localize("SWIM.notification.monksTileTriggersNotFound"))
            console.warn("The campfires module in SWIM works best when using Monks Active Tiles module. It allows you to simply double click the campfire to delete it and its associated light and ambient sound. This is no requirement but without it you'll have to manually delete the tile, light and sound.")
        }
    }
}