/* globals game, FormApplication, $ */

import * as SWIM from './constants.js'
import { swim_buttons } from './buttons.js'
import { SwimConfigApp } from './helpers/swim_config.js'
import { SwimWindow } from './helpers/swim_window.js'
import { DEFAULT_LISTS, serialize_list } from './helpers/swid_lists.js'

export const settingVariables = [
    {id: 'swdUnshake', config_type: Boolean, tab: "Setting Rules", default: false, reload: true},
    {id: 'grittyDamage', config_type: Boolean, tab: "Setting Rules", default: false},
    {id: 'grittyDamageNPC', config_type: Boolean, tab: "Setting Rules", default: false},
    {id: 'natHeal_Time', config_type: String, tab: "Setting Rules", default: 'five days'},
    {id: 'npcAmmo', config_type: Boolean, tab: "Setting Rules",  default: false},
    {id: 'noPowerPoints', config_type: Boolean, tab: "Setting Rules",  default: false},
    // SWID lists with their own editor window (helpers/list_editor.js), stored as JSON text (helpers/swid_lists.js)
    {id: 'potionSwids', config_type: String, tab: "Item Options", editor: true, default: serialize_list(DEFAULT_LISTS.potionSwids)},
    {id: 'visionSwids', config_type: String, tab: "Item Options", editor: true, default: serialize_list(DEFAULT_LISTS.visionSwids)},
    // The compendium with the Edges (any Item compendium); Warrior's Gift (Effect Builder) offers its Combat Edges (helpers/combat_edges.js)
    {id: 'edgesPack', config_type: String, tab: "Item Options", default: 'none', options: SWIM.get_compendiums_list, type: 'item'},
    {id: 'specialAbilitiesPack', config_type: String, tab: "Tables & Playlists", default: 'none', 
        //assigned the function get_compendim_list to options instead of its results. As the function is not called it is not executed yet.
        options: SWIM.get_compendiums_list, type: 'item'
    },
    {id: 'injuryTable', config_type: String, tab: "Tables & Playlists", default: 'Injury Table'},
    {id: 'fearTable', config_type: String, tab: "Tables & Playlists", default: 'Fear Table'},
    {id: 'backlashTable', config_type: String, tab: "Tables & Playlists", default: 'Dynamic Backlash'},
    {id: 'chaseDeck', config_type: String, tab: "Tables & Playlists", default: 'Chase Deck'},
    {id: 'encounterTableEnemies', config_type: String, tab: "Tables & Playlists", default: 'Travel Encounters: Enemies'},
    {id: 'encounterTableObstacles', config_type: String, tab: "Tables & Playlists", default: 'Travel Encounters: Obstacles'},
    {id: 'encounterTableStrangers', config_type: String, tab: "Tables & Playlists", default: 'Travel Encounters: Strangers'},
    {id: 'encounterTableTreasures', config_type: String, tab: "Tables & Playlists", default: 'Travel Encounters: Treasures'},
    {id: 'combatPlaylistManagement', config_type: Boolean, tab: "Tables & Playlists", default: true},
    {id: 'combatPlaylist', config_type: String, tab: "Tables & Playlists", default: 'Combat'},
    {id: 'noStopFolder', config_type: String, tab: "Tables & Playlists", default: 'Ambient'},
    {id: 'chaseDeck-MaxCards', config_type: Number, tab: "Chase Layout", default: '18'},
    {id: 'chaseDeck-CardsPerRow', config_type: Number, tab: "Chase Layout", default: '9'},
    {id: 'chaseDeck-CardsToDraw', config_type: Number, tab: "Chase Layout", default: '18'},
    {id: 'chaseDeck-GridWithPixels', config_type: Number, tab: "Chase Layout", default: '50'},
    {id: 'chaseDeck-BorderHorizontal', config_type: Number, tab: "Chase Layout", default: '0'},
    {id: 'chaseDeck-BorderVertical', config_type: Number, tab: "Chase Layout", default: '0'},
    {id: 'chaseDeck-CardHeight', config_type: Number, tab: "Chase Layout", default: '6'},
    {id: 'chaseDeck-CardWidth', config_type: Number, tab: "Chase Layout", default: '4'},
    {id: 'chaseDeck-DeckDown', config_type: Number, tab: "Chase Layout", default: '24'},
    {id: 'chaseDeck-DeckRight', config_type: Number, tab: "Chase Layout", default: '10'},
    {id: 'shapeChange-raiseScaleMultiplier', config_type: Number, tab: "Macro Options", default: SWIM.RAISE_SCALE_DEFAULT,
        min: SWIM.RAISE_SCALE_MIN, max: SWIM.RAISE_SCALE_MAX, step: 0.01},
    {id: 'shapeChange-numMorphs', config_type: Number, tab: "Macro Options", default: SWIM.NUM_MORPHS_DEFAULT,
        min: SWIM.NUM_MORPHS_MIN, max: SWIM.NUM_MORPHS_MAX, step: 1},
    {id: 'effectBuilder-usePowerIcons', config_type: Boolean, tab: "Macro Options", default: false},
    {id: 'ignoreShapeChangeSizeRule', config_type: Boolean, tab: "Macro Options", default: false},
    {id: 'mirrorToken', config_type: String, tab: "Macro Options", default: "character", 
        options: [
            {value: 'all', locaString: 'SWIM.Option-characterAndNPC'},
            {value: 'character', locaString: 'SWIM.Option-characterOnly'},
            {value: 'npc', locaString: 'SWIM.Option-npcOnly'},
            {value: 'disabled', locaString: 'SWIM.Option-disabled'}
        ]},
    {id: 'campfireImgOn', config_type: String, picker: 'video', tab: "Macro Options", default: ""}, //recommendation: modules/jb2a_patreon/Library/Generic/Fire/Campfire/Bonfire_02_Regular_Orange_400x400.webm
    /* Comment that out for the moment as I have no idea yet how to change the behaviour on blind. Maybe this is better suited in SUCC anyway.
    {id: 'blindMode', config_type: String, tab: 'Macro Options', default: 'none', 
        options: [
            {value: 'none', locaString: 'SWIM.Option-noEffect'},
            {value: 'sense', locaString: 'SWIM.Option-senseAll'},
            {value: 'tremor', locaString: 'SWIM.Option-tremorSense'},
            {value: 'full', locaString: 'SWIM.Option-fullBlind'},
        ]},*/
    {id: 'customTravelOptions', config_type: String, tab: "Macro Options", default: ""},
    {id: 'br2Support', config_type: Boolean, tab: "SFX & VFX Options", default: false, reload: true},
    {id: 'br2ammoMgm', config_type: String, tab: "SFX & VFX Options", default: "full", reload: true,
       
        options: [
            {value: 'full', locaString: 'SWIM.Option-full'},
            {value: 'sfx', locaString: 'SWIM.Option-sfxOnly'},
            {value: 'disabled', locaString: 'SWIM.Option-disabled'}
        ]},
    {id: 'sfxDelay', config_type: Number, tab: "SFX & VFX Options", default: '110'},
    {id: 'defaultVolume', config_type: Number, tab: "SFX & VFX Options", default: '1' },
    {id: 'shakenSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Pain-sound-effect-converted-Alexander-www.orangefreesounds.com.ogg'},
    {id: 'incapSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/HeartBeat-sound-effect-2-altered-Alexander-www.orangefreesounds.com.ogg'},
    {id: 'stunSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Body-Thud-altered-www.fesliyanstudios.com.ogg'},
    {id: 'woundedSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Ripping-Flesh-altered-www.fesliyanstudios.com.ogg'},
    {id: 'geigerSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/geiger-counter-radioactive-62113_freesound_community-033842-modified.ogg'},
    {id: 'fatiguedSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Hard-Breathing-Medium-Pace-altered-www.fesliyanstudios.com.ogg'},
    {id: 'fearSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Suspense_Sound_Effect_altered_-_David_Fesliyan-www.FesliyanStudios.com.ogg'},
    {id: 'healSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Huh-converted-Alexander-www.orangefreesounds.com.ogg'},
    {id: 'healVFX', config_type: String, picker: 'video', tab: "SFX & VFX Options",
        default: ''},
    {id: 'looseFatigueSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Huh-converted-Alexander-www.orangefreesounds.com.ogg'},
    {id:  'potionSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Drinking-Water-altered-www.fesliyanstudios.com.ogg'},
    {id: 'shapeShiftSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: ''},
    {id: 'shapeShiftVFX', config_type: String, picker: 'video', tab: "SFX & VFX Options",
        default: ''},
    {id:  'lightSFX', config_type: String, picker: 'audio', tab: "SFX & VFX Options",
        default: 'modules/swim/assets/sfx/Fireball-Super-Quick-Whoosh-www.fesliyanstudios.com.ogg'},
    {id: 'callbackMode', config_type: String, tab: 'Misc', default: 'manual', reload: true,
       
        options: [
            {value: 'manual', locaString: 'SWIM.Option-manual'},
            //{value: 'automatic', locaString: 'SWIM.Option-automatic'},
            {value: 'disabled', locaString: 'SWIM.Option-disabled'}
        ]},
    {id: 'deleteEffectsAfterCombat', config_type: Boolean, tab: "Misc",  default: false},
    {id: 'automaticVision', config_type: Boolean, tab: "Misc",  default: true},
    {id: 'auraEffects', config_type: Boolean, tab: "Misc",  default: true},
    {id: 'absorbSheetBonus', config_type: Boolean, tab: "Misc",  default: true},
    {id: 'brswBacklash', config_type: String, tab: "Misc", default: "regular",
        options: [
            {value: 'regular', locaString: 'SWIM.Option-regular'},
            {value: 'dynamic', locaString: 'SWIM.Option-dynamic'},
            {value: 'disabled', locaString: 'SWIM.Option-disabled'}
        ]},
];

export function register_settings() {
    // Old potion name lists: not shown and not used any more, only read once to build the SWID list (migrate_potion_names)
    game.settings.register('swim', 'healthPotionOptions', { type: String, default: 'Minor Health Potion|Health Potion|Greater Health Potion|Minor Healing Potion|Healing Potion|Greater Healing Potion', scope: 'world', config: false });
    game.settings.register('swim', 'fatiguePotionOptions', { type: String, default: 'Minor Potion of Well-Being|Potion of Well-Being|Greater Potion of Well-Being|Minor Recreational Potion|Recreational Potion|Greater Recreational Potion', scope: 'world', config: false });
    game.settings.register('swim', 'potionSwidsMigrated', { type: Boolean, default: false, scope: 'world', config: false });
    // Documentation Read
    game.settings.register('swim', 'docReadV1.1.0', {
        name: game.i18n.localize("SWIM.docReadName"),
        hint: game.i18n.localize("SWIM.docReadHint"),
        type: Boolean,
        default: false,
        scope: 'world',
        config: true,
    });
    game.settings.register('swim', 'allowUserConfig', {
        name: game.i18n.localize("SWIM.allowUserConfigName"),
        hint: game.i18n.localize("SWIM.allowUserConfigHint"),
        type: Boolean,
        default: true,
        scope: 'world',
        config: true,
    });
    game.settings.register("swim", "raiseCalculator", {
        name: "SWIM.activateRaiseCalculatorButtonName",
        hint: "SWIM.activateRaiseCalculatorButtonHint",
        type: Boolean,
        default: true,
        scope: "world",
        config: true,
        onChange: (value) => {
            // the getSceneControlButtons hook (init.js) checks the setting itself
            ui.controls.render({ reset: true });
        },
    });
    game.settings.register('swim', 'br2Message', {
        name: "br2MessageName",
        hint: "br2MessageHint",
        type: Boolean,
        default: false,
        scope: 'world',
        config: false,
    });
    game.settings.registerMenu('swim', 'custom-config', {
        name: game.i18n.localize("SWIM.ConfigMenuName"),
        label: game.i18n.localize("SWIM.ConfigMenuLabel"),
        icon: 'fas fa-swimmer',
        hint: game.i18n.localize("SWIM.ConfigMenuHint"),
        type: SwimConfigMenu
    });
    for (let setting of settingVariables) {
        //Check if a setting has an options property and if this option is a function. If both are true, sustitute the function for its result with a param of setting.type. That way we dealy when it is called.
        if (Object.hasOwn(setting, 'options') && setting.options instanceof Function) {
            console.log("SWIM | LOADING OPTIONS")
            setting.options = setting.options(setting.type);
            console.log(setting.type)
            console.log(SWIM.get_compendiums_list(setting.type));
        }
        game.settings.register('swim', setting.id, {
            name: game.i18n.localize(`SWIM.${setting.id}Name`),
            hint: game.i18n.localize(`SWIM.${setting.id}Hint`),
            type: setting.config_type,
            default: setting.default,
            scope: 'world',
            config: false
        });
    }
}

/** The settings menu has to be an ApplicationV2 for Foundry; it only opens the SWIM window (SwimConfigApp) and never renders itself. */
class SwimConfigMenu extends foundry.applications.api.ApplicationV2 {
    render() {
        SwimWindow.show(new SwimConfigApp(settingVariables))
        return this
    }
}
