# SWIM – Final regression checklist (Foundry v11 / SWADE 3.3.11)

Run this once before the release, **after the version bump**. Keep the console (F12) open: any red error or deprecation warning that mentions SWIM is a failure.
Source: the "needs live test" column of the change log in `PROJECT_SUMMARY.md` (#number = changeset).

Legend: `[ ]` = run it now. **(was tested at #N)** = passed once on the user's world, re-check quickly. **(never tested)** = nobody has ever run this path, give it extra attention.

## 0. Test setup
- World with SWADE 3.3.11, SUCC 3.3.0, socketlib, portal-lib 1.0.7, Sequencer (optional), **without** Warp Gate, settings-extender and lib-wrapper.
- Accounts: one **GM**, one **player** with the permissions *Create Tokens* (and one without, for the Summoner error), the player owns a character token.
- A second world/profile **with Power Points enabled** (the PP backlog below), and one with the SWIM "no Power Points" option.
- Firefox users: see the DMABUF note in the change log (#25) if icon colours look wrong – not a SWIM issue.

## 1. Load, settings, migration
- [ ] World loads as GM and player, no errors, no dependency prompts (**tested at #21/#22**).
- [ ] SWIM settings menu opens, all tabs show, audio/video file pickers work, values persist (**tested at #22**).
- [ ] No migration dialogs on load. Opening the SWIM config of an old (version-less) actor/item gives **one** migration popup, none on the next open (#36).
- [ ] `await swim.migrate_world()` as GM (backup first): start + result notice, no errors, second run migrates 0; as a player: error notice (**tested at #36**).
- [ ] Config window (actor + item): fields show; an Active Effect that adds to `flags.swim.config.radRes` shows the **source** value plus an "effective value" line; open + save repeatedly does **not** grow the value; changing a field saves only that field (#38).
- [ ] Ammo item config: "set active effect" button works, icon default is the item image (#30); shows *Effect set / No effect set*, remove works, edit is disabled on owned items; temporary effects vanish after Save **and** Cancel (#62).
- [ ] Actor/item SWIM Config (#62, rebuilt as a window): rows for the document type only (weapon / ammo / character+npc); sound fields have a folder and a **play** button; reset, changed highlight, Save disabled without changes; Cancel/X discards (the old window saved on close); only changed values are written; image picker for the mirror self image.

## 2. Sound (SFX) – new core audio path (#38)
- [ ] An SFX plays **for all** clients where it did before (e.g. Unshake, Soak, Mark Dead, Shape Change) and **only for the triggering player** for the Geiger Counter SFX.
- [ ] Setting "Default Volume" (e.g. 0.3) now changes the volume of **every** SWIM sound, including the ones that used to ignore it.
- [ ] Empty SFX field = silence, no console error. A wrong file path = one console warning, macro continues.
- [ ] Health Centre potion (health and fatigue, self and other): the sound plays, the heal step waits for it to finish, wounds/fatigue are reduced, quantity drops (**regression from #38 found at #40, fixed at #41**).

## 2b. Actor state sounds – hooks (#40), the most important new area
Test on a **linked** token (character) **and an unlinked** NPC token (unlinked: does it play at all?), as GM and as player. One sound per event, never two at once.
- [ ] Wounds: take a wound (BRSW damage card, SWADE damage dialog, Soak "apply wounds", **and by hand on the sheet**) → `shakenSFX` once, also if Shaken is added at the same time.
- [ ] Heal wounds (Health Centre self, Heal Other, sheet) → `unshakeSFX` once (+ heal VFX if configured, no second sound).
- [ ] Shaken applied (`swim.shake`, Tester result, BRSW) → shaken sound; Shaken removed by Unshake (success, SWD, SWADE, Benny after failed roll), by Soak "all wounds soaked" (soak sound + no doubled sound with default settings) or by hand → unshake sound.
- [ ] Stunned applied (`swim.stun`, Fear Table, Tester) → stunned sound; removed by Unstun/Heal Other → unshake sound.
- [ ] Incapacitated / Bleeding Out / Dead applied (Soak, Health Centre crit fail, Heart Attack cure, Backlasher, Mark Dead on character and NPC) → death sound once; Mark Dead again (reviving: Incapacitated/Dead removed) → soak sound once.
- [ ] Fatigue up (Radiation Centre, Backlasher, by hand) → fatigued sound; down (Health Centre fatigue cure, Heal Other relief, by hand) → loose-fatigue sound.
- [ ] Hit that adds Shaken + Wound + Incapacitated at once → only the death sound.
- [ ] Player changes their own wounds on the sheet → everybody hears it exactly once.
- [ ] BRSW with *Better Rolls 2 support* **off**: sounds still play (hooks do not depend on it); BRSW soak (needs support **on**) plays the soak sound.
- [ ] Not played: effect with other statuses (Prone, Distracted, Vulnerable), disabled effects, an empty SFX field. No SFX at combat end / scene change / reloading the world.
- [ ] No console errors/warnings "Could not play actor SFX".

## 3. Soak, injuries, Heal Other, Health Centre
- [ ] **Soak** with Bennie as player and GM; Incapacitated / Bleeding Out / dead overlay; no `defeated`/mapping error (**tested at #10, #23**).
- [ ] Soak reroll shows last roll, best result and wounds received (**tested at #29 in the old dialog; now inline, see 3c**).
- [ ] Injury table result creates the effect with the right name (+ " (combat)"/" (permanent)") and icon (**tested at #12, #28**).
- [ ] BRSW: apply an injury from the BRSW chat card → effect gets the SWIM name/icon (**partly tested at #28 – only the SFX hook was seen**).
- [ ] **Heal Other** (success, raise, crit fail, relief): dialogs without "undefined", chat texts correct, Bleeding Out/Incapacitated removal (**tested at #10, #17**).
- [ ] **Health Centre** own healing, wound/fatigue dialogs (text "2/3 Fatigue", no "undefined" in potion list) (**tested at #32**).
- [ ] Potions: gear (qty drops, removed at 0) and SWADE consumable (charges/stack, "destroy on empty" on/off); health and fatigue variants (**tested at #32**).
- [ ] Healing / wound SFX and the Incapacitated overlay toggling after a heal or a critical failure (**tested at #35**).

## 3b. Personal Health Centre – one window (#45, never tested)
- [ ] Styles load (`styles/health-centre.css`): dark window, patient card, Wounds/Fatigue blocks, no console errors.
- [ ] **No target**: no patient switch; opens on Wounds (or Fatigue if no Wounds); with neither: "nothing to do" and Close. Target = yourself counts as no target.
- [ ] **Target selected** (another token): switch shows Myself | Target, target is the default, switching back to Myself works; chips (Incapacitated, Bleeding Out, Heart Attack, Shaken, Stunned) and pips match the patient; pips update live if the actor changes while the window is open.
- [ ] **Self, Natural Healing**: roll → result shown in the window (roll, edges, healed Wounds, conditions), Accept applies and posts the chat message, **Reroll with Benny** spends a Benny and rolls again (Elan +2 on rerolls), Close on 0 Wounds healed posts the "unable to heal" message; crit fail → one more Wound (Incapacitated beyond max), no soak dialog; Bleeding Out/Incapacitated are removed before Wounds; max 2 Wounds.
- [ ] **Self, Direct healing** (stepper, limit = Wounds + Bleeding Out + Incapacitated) and **Cure Fatigue** (chat message "lost X levels").
- [ ] **Self, Potion** (gear and SWADE consumable, health and fatigue): only potions with quantity/charges left are listed; sound plays and is waited for; chat; quantity/charges drop; Wounds/Fatigue reduced.
- [ ] **Other, Healing roll**: Critical Failure / Failure / Success / Raise with Wounds and with Fatigue (relief), "used in combat" box; Failure = "nothing to do" notice; as player and as GM; payload to the GM unchanged (no "rejected" warning).
- [ ] **Other, Potion**: list shows own potions ("yours") **and** the target's potions ("<Target>'s"); using the healer's potion consumes the healer's item, using the target's consumes the target's item; target is healed (conditions first, then Wounds/Fatigue), chat message differs ("gives" vs "helps … to use his"), works as a **player** that does not own the target; target's potions are only listed with at least observer permission (GM always); no GM online → red notice.
- [ ] Old dialogs are gone: no confirm dialog before the window, no sub-dialogs.

## 3c. Soak Damage – one window (#47, never tested)
- [ ] Styles load (`styles/soak-damage.css`, relies on `health-centre.css`): same dark look as the Health Centre, no console errors. Only one Soak window at a time.
- [ ] **Choose**: incoming Wounds stepper (default 1, pips show hatched ghost Wounds), Soak card is greyed out without Bennies or with 0 Wounds; preview line matches the choice.
- [ ] **Soak roll**: Benny is spent *after* the roll (cancel the roll -> no Benny lost); result view shows roll, soaked Wounds, Apply (remaining Wounds) and *Reroll with Benny* (only while Bennies are left and it can help; Elan +2 on rerolls; best result is kept). All soaked -> Shaken removed, soak sound, chat message, window closes.
- [ ] **Critical failure** on the Soak roll: all Wounds apply (editable), chat message.
- [ ] **Holy/Unholy Warrior**: PP stepper (max 4 / available), PP leave the **general** pool after the roll and are added to the roll.
- [ ] **Soak bonuses**: Active Effect `soakBonus`, Iron Jaw / Thick Fur (not doubled with an AE of the same name), Elan on reroll – listed in the result.
- [ ] **Take the damage**: Wounds + Shaken; Gritty Damage (PC / NPC settings) rolls an injury only if a new Wound was taken and the max is not exceeded; injury effect has name and icon.
- [ ] **Exceeding max Wounds**: Character -> Incapacitated with overlay, window continues with the Incapacitation roll (<4 permanent injury + Bleeding Out, otherwise temporary injury, 8+ with the 24 h text); NPC / vehicle -> Dead, window closes.
- [ ] **Bleeding Out** (macro or the Bleeding Out effect): window opens on the Vigor roll. <4 dead (or Harder To Kill 1d2), 4-7 still bleeding, 8+ stabilises (Incapacitated overlay stays). Reroll with Bennies inline. Incapacitated without Bleeding Out opens on the Incapacitation roll.
- [ ] **Critical failure** on those rolls: perish, or Harder To Kill 1d2 and survive without Bleeding Out.
- [ ] Soak sound plays once (hooks do the rest); wound/shaken/incapacitated sounds are not doubled. As player and as GM.
- [ ] No console output from `swim.check_bennies()` any more.

## 3d. Unshake – one window (#48, tested at #48: "works")
- [x] Styles load (`styles/unshake.css`): same dark look as Soak/Health Centre; header shows token, chips, Spirit die / Bonus / Bennies.
- [x] Macro on a Shaken token (GM and player): opens on "Spirit roll"; "Spend a Benny" greyed out without Bennies.
- [x] SWADE rules: 4+ frees (window closes, chat); 3 or less -> result view, still Shaken; "Spend Benny & act" removes Shaken (one Benny, chat with Benny image); Close keeps Shaken.
- [x] Direct "Spend a Benny" (no roll). Old Ways Oath: one "Free reroll" after a failed roll, also with 0 Bennies.
- [x] SWD rules (setting on): 8+ frees; 4-7 = no longer Shaken but can't act + Benny offered; 3 or less = still Shaken.
- [x] Critical Failure: only Close (intended: a Critical Failure prevents further rerolls). Cancelled roll dialog: nothing happens.
- [x] Bonus block: Combat Reflexes +2, `unShakeBonus` effects by name; Edge + same-named effect not doubled.
- [x] SWADE start-of-turn Shaken prompt opens the window; macro on a non-Shaken token Shakes it; removing Shaken from the HUD closes the window; unshake sound once.

## 3e. Unstun – one window (#49, never tested)
- [ ] Opens on the Vigor prompt (rules text, bonus lines, Cancel / Roll Vigor); header with chips (Stunned, Distracted, Vulnerable, Prone), Vigor die, Bonus, Bennies.
- [ ] Roll 8+: Stunned and Distracted removed, window closes, chat message. Roll 4-7: Stunned removed, Vulnerable added, result view with *Reroll with Benny*. Roll 3 or less: still Stunned, reroll offered.
- [ ] Reroll: Benny spent **after** the roll (cancel the roll -> no Benny lost); Elan +2 on rerolls (hint + line in chat); a worse reroll keeps the better result ("best result so far is kept", conditions unchanged); a better one applies its result (4-7 -> 8+ removes Distracted).
- [ ] Critical Failure: chat message, only Close (no reroll), still Stunned. No Bennies: no reroll button.
- [ ] Bonuses: Combat Reflexes +2; effects on `system.attributes.vigor.unStunBonus` and the legacy key `SWIM.unStunMod` listed by name; several effects add up correctly; Edge + same-named effect not doubled.
- [ ] SWADE start-of-turn Stunned prompt opens the window for the right token; macro on a non-Stunned token Stuns it (no window); removing Stunned from the HUD while the prompt is open closes the window; unshake sound once (hook).

## 3f. Radiation Centre – one window (#50, never tested)
- [ ] Opens with Geiger sound **only for the user who opened it** (setting empty = silence); header shows Fatigue pips (value/max), Rad Resistance (signed) and Bennies; macro with 0 or 2+ tokens selected: error notice.
- [ ] **Roll** card (default): preview lists the Rad Resistance bonus (positive and negative, no "--2"); 4+ (incl. bonus) = no Fatigue, chat message, window closes; below 4 = result view with chat "would take a Level of Fatigue".
- [ ] **Failed roll with Bennies**: *Reroll with Benny* (Benny spent **after** the roll, chat message about the Benny, Elan +2 shown in the result/chat), *Take the Fatigue* applies it (notice) and closes. Without Bennies and without Soldier: Fatigue is applied at once with the "no more Bennies" notice.
- [ ] **Soldier**: after a failed roll only *Free reroll* is offered (no Benny spent); after it was used the Benny reroll follows.
- [ ] **Apply Fatigue** card: +1 Fatigue without a roll, no chat message. Critical Failure on the roll: chat message + Fatigue at once.
- [ ] Cancelling the Vigor roll dialog: nothing happens, no Benny lost, window stays.
- [ ] **Fatigue beyond the maximum**: preview text says so; character becomes Incapacitated (overlay) and gets the chronic disease effect *Radiation Poisoning* **with name and icon** (+ chat message + warning), only once; NPC/vehicle is marked dead; Fatigue stays at the maximum; already Incapacitated stays Incapacitated (not toggled off); other selected tokens are not touched.
- [ ] Fatigue sound plays once (hook).

## 3g. Tester – one window + GM resist window (#51/#52, never tested)
- [ ] **#52b:** dropdowns sorted: own skill list A-Z; Support's list = Attributes A-Z then target's Skills A-Z (prefixes ignored for sorting).
- [ ] **#52:** *Test* roll of 8+ (raise) or with no Bennies/free reroll left: the window stays on the result view (total, hint "Apply it when you are ready") with only *Apply*; nothing is sent until Apply. With rerolls available: *Reroll* + *Apply*. *Support* roll 8+ / no reroll left still sends at once. Test Critical Failure still sends at once (chat only).
- [ ] Needs one selected token + one target (else error). Window shows the intro with a working document link, method cards **Support** / **Test**, skill selects, preview. Test: *Desired result* options (Distracted / Vulnerable) and the PC-vs-NPC caution for GM or PC targets.
- [ ] **Support** as player: roll 8+ -> sent at once (no reroll); 4-7 -> result view with *Reroll with Benny* (Benny spent **after** the roll, Elan +2 shown) and *Apply*; best result kept. Support effect appears on the target (+1 / +2, name, correct trait); a second Support on the same trait updates it, max +4. Critical Failure: -2, sent at once.
- [ ] **Reliable** (Support) / **Humiliate** + Taunt (Test): *Free reroll* offered once, also with 0 Bennies, costs nothing; afterwards the Benny reroll. Cancelling the roll dialog: nothing happens, no Benny lost.
- [ ] **Test**: the GM gets the *Resist the Test* window (target shown, needed total, Strong Willed/Elan of the **target**). Resist OK = chat only. Failed = chosen condition on the target, Shaken if the test beat the resist by 4+; target's Benny reroll spent after the roll. Retort (Edge on the **target**, Taunt/Intimidation, resist beats test by 4+) distracts the tester. Menacing +2 only on Intimidation. Tester Critical Failure: chat only, no GM window. Resist Critical Failure: **no** extra Benny lost. Elan +2 only when a Benny is spent for the reroll, never on a free reroll. **All SWIM texts show real words, not raw keys `SWIM.…` (hotfix check).**
- [ ] Link style check (any SWIM window with a document link): red, underlined, no grey box, no icon. Radiation Centre: button says *Gain Fatigue*, failed-roll text says "You may spend a Benny to reroll." (Soldier: "free reroll").

## 3h. Travel Calculator – one window (#52, never tested)
- [ ] Window opens with the distance field focused; km/miles toggle, method select, *Generate random encounters* only if all four tables exist (else the warning text), stealth checkbox. Enter in the distance field = Calculate.
- [ ] Invalid distance (empty, 0, text) -> error notice, window stays. Decimals (`12.5`, `12,5`) work.
- [ ] **Without encounters:** image popout shown to all (not in stealth), sound plays (not in stealth), window switches to the result view (distance, means, 8 h/day, non-stop, note) and is on top of the image; Close.
- [ ] **With encounters:** journal in "[SWIM] Journeys" is created and opened, image shown, window closes; same content as before.
- [ ] **Encounter tables** button -> second view with four selects (current tables preselected; with and without the "[SWIM] Encounter Tables" folder); *Save tables* stores them and returns to the form, *Back* discards; a new table choice is used straight away (encounter checkbox appears/disappears accordingly).

## 3i. Common Bond, Deviation, Dramatic Task Planner – windows (#53, never tested)
- [ ] **Common Bond** (one selected token with the Edge + one target, as player and as GM): window shows both portraits with an arrow, your Bennies and the confirmation text. *Give Benny*: your Benny is spent, the target gets one, chat message as before, window closes. *Cancel* costs nothing. Errors as before: no Edge / no Bennies / no or several targets (notice, no window). Check the player case for a "rejected" GM warning (none expected).
- [ ] **Deviation** (macro / `swim.deviation()`): window with weapon type (Projectile preselected) and range (Short preselected); *Roll Deviation* posts the chat message (thrown = 1d6, projectile = 2d6, times 1-4 for the range; the half-distance warning on 4-8 o'clock) and closes. `swim.deviation('thrown','long')` rolls without a window.
- [ ] **Dramatic Task Planner** (with 0, 1 and several targeted tokens): Players preset to the number of targets; the difficulty options give 4/6/8 tokens per player and 3/4/5 turns; custom tokens + turns (both > 0) override; *One task per player* posts one block per player (with the token names if the number of targets equals the number of players), also **without** Challenge Tracker; Play SFX; GM-only whisper; with Challenge Tracker installed the three CT options and the tracker window(s).

## 3j. Falling Damage, Loot-o-Mat – windows (#54, never tested)
- [ ] **Falling Damage** with one selected token, with several (selected + targeted, no duplicates), and with none (error). Each token has Depth / Snow / Water. Roll: one chat message with a block per token; damage per 2" = 1d6x+1 (max 10 dice), snow subtracts its depth (never below 0), water Success halves, Raise = no damage; Shaken / Wounds text with the Wounds link, Hardy when already Shaken. Water + snow on one token: error, nothing posted, window stays.
- [ ] **Loot-o-Mat**: (a) selected/targeted tokens whose actors carry the *treasure* additional stat ("Meager", "Rich, per 5", "Worthwhile/4", "Treasure Trove") roll straight to chat (heading + image by size, "your enemy"/token name/"your enemies"); (b) no token: window with four amounts, *Roll* with all 0 = notice; (c) token without the stat: window with the "did not detect" text; chat text with several enemies says "your enemies".

## 3k. Fear Table, Raise Calculator, Scene Illumination, Summoner Dismiss – windows (#55, never tested)
- [ ] **Fear Table** (one selected + several targeted): window shows the source token, the detected modifier (e.g. "Fear -2" -> field preset 2), the targets as chips; Enter or *Roll on the Fear Table* rolls 1d20 + modifier per target (chat message per target + effects as before, SFX), window closes. Empty modifier = 0. Missing/unknown table setting: error notice, window stays. No selection / no targets: error, no window. Also check the results themselves again (3: see section 4 / Fear Table).
- [ ] **Raise Calculator** (toolbar button and macro/init call): typing target + roll updates icon + text live (failure red, success yellow, 1 Raise / n Raises green); empty field = neutral "Result"; opening it twice keeps one window; Close.
- [ ] **Scene Illumination** (scene controls button, GM): preselect = stored level, else derived from the scene darkness (<=0.1 full, <=0.5 dim, <=0.75 dark, else pitch); *Save* writes `flags.swim.config.illuminationLevel`, notice "Illumination level for this scene updated.", window closes; *Cancel* changes nothing. Token Vision / light still react to the level as before.
- [ ] **Summoner Dismiss** (select a summoned creature as its owner / GM): confirmation window with the creature's name; *Dismiss Creature* plays VFX/SFX, removes the creature, maintenance effects and mirror actor as before; *Cancel* / closing the window does nothing.

## 3l. Effect Builder – window (#56, never tested)
- [ ] Open from a power item's macro/button (with `item`) for: Boost/Lower Trait (preselects *Boost Trait*; switching to *Lower Trait* keeps the item linked), a power the builder does not support (e.g. Blast: opens *Other* with Blast selected in the caster's power list), a power without SWID (also *Other*), and without item (preselects *Boost Trait*). Sound/Silence preselects *Silence*.
- [ ] Search: typing filters the list live (accent/case insensitive, several words), *No power found* when empty, Enter picks the first hit, Arrow down/up moves through the list, Escape clears the text; the selected power stays selected when filtered out.
- [ ] Options per power as before: Boost/Lower (Attribute/Skill per target, Attributes A-Z then Skills A-Z, Raise), Protection (amount + Armour/Toughness), Smite (weapon per target that has one + bonus), Growth/Shrink (size steps; Shrink negative), Speed/Sloth (quickness), Ease Burden (steps; 0 -> notice, window stays), Deflection (attack type), Light (hint + beam/raise), Burrow/Conceal (Strong), Damage Field (**Damage Modifier now gives 2d6**), the rest with Raise, *Other* (the caster's powers, duration only without the *no power points* setting).
- [ ] Apply: effect(s) appear as before on all targets, maintenance/PP logic unchanged, caster penalty only if the caster is not a target; also as a **player** (GM relay). Conceal Arcana, Slumber, Environmental Protection and Intangibility no longer throw an error.

## 3m. Chase Setup + Ammo Management – windows (#57, never tested)
- [ ] **Ammo, Reload:** *Bullets to load* defaults to the weapon's max magazine; *Max (n)* / *Just 1* set it; typing a number works; loading 1 into a half-empty weapon adds exactly 1 and takes 1 ammo; a number larger than the free space or your ammo only loads what fits; 0 / empty -> notice, nothing changes. Single-reload weapons show the extra hint. Weapon switch resets the amount, ammo and shots; a Charge Pack hides the amount field and still fully charges.
- [ ] **Ammo, ammo type change:** old rounds go back to the old ammo, new ammo is loaded with the chosen number (not more than you own); ammo Active Effect applied as before. NPC without inventory ammo: amount adds to the magazine, capped at max.
- [ ] **Ammo, Shoot mode:** shots default to the full ROF, limited by the loaded rounds; sounds as before; consumable weapons use up quantity.
- [ ] **Chase Setup:** Tables/Cards switch shows the right selects; *Draw* places the tiles (more than the max -> error + max used); *Reset* shuffles back and removes only the flagged tiles; layout options stay open/closed across the switch; window closes after Draw/Reset.

- [ ] **Chase Setup layout options:** unfolding them grows the window (scrolls if the screen is too small), folding shrinks it again. **Effect Builder (#58):** Boost and Lower on an attribute and on a skill apply without error (also as a player); dropdown shows "| Attribute | Agility" / "| Skill | Fighting". **Travel Calculator:** a Joker among the drawn cards is replaced.

## 3n. Token Vision – window + ATL light (#59/#60, never tested)
- [ ] **One token** (GM and player): the window opens with *Automatic* selected, the advanced fields already show the estimate. A token with an ability whose SWID is `darkvision` / `infravision` / `low-light-vision` shows that type in the preview (check all three, and one with two: Darkvision wins); a token without shows *Basic sight*. Works with the ability named in another language.
- [ ] **Scene illumination:** the scene's *Scene Illumination* level (Scene Illumination button) sets the range (Full 1000, Dim 25, Dark 10, Pitch 0); without a flag the scene darkness is used; the *Illumination* row overrides it; Low Light Vision in Pitch = basic sight.
- [ ] **Special vision only with benefit (#60):** Darkvision shows Basic sight in Full/Dim/Dark and Darkvision in Pitch; Low Light Vision Basic in Full/Dim, special in Dark, basic again in Pitch; Infravision/Night Vision Device special from Dark on (Infravision keeps basic sight enabled + heat detection 25); no tint/grey vision where it gives nothing.
- [ ] **Scene hook (#60, GM):** change the scene's illumination -> all tokens (with vision enabled) update at once, light sources unchanged, no change if nothing differs; drop a new token/summon on a scene with an illumination level -> it is set up automatically; scene without a level or tokens with *Vision enabled* off are left alone; with two GMs online only one does it.
- [ ] **Automatic vision adjustments setting (#61):** on (default): illumination change / new token set vision up as before. Off: neither the scene illumination change nor a placed token changes any vision; the Token Vision macro's *Automatic* card still works when started manually. Tokens with *Vision enabled* off are skipped in both cases (the macro's preview says so).
- [ ] **Apply** (nothing changed): the token's vision range/mode/detection modes match the preview; other detection modes the token had (e.g. See Invisibility) stay. Vision mode change also takes over the mode's defaults. Night Vision Device plays the on/off sound.
- [ ] **Infravision / SWADE modes:** assumes the SWADE system registers vision mode `infraVision` and detection mode `seeHeat` (as the old macro used). If your world lacks them it falls back to Darkvision mode - tell me what you see.
- [ ] **GM, several tokens:** the notice and the per-token list show different types; Apply gives each its own vision; picking e.g. Darkvision applies it to all; a player with several tokens selected gets the old "select a single token" error.
- [ ] **Custom / advanced:** editing any advanced field switches the card to *Custom* (without losing the click on Apply); the values are applied exactly.
- [ ] **Light (needs ATL):** Torch/Candle/Lantern/Bullseye/Flashlight create one Active Effect (icon, name) with `ATL.light.*` changes; the token shines at once (also unlinked tokens, also as a player on their own token); applying another source updates the same effect; *None* removes it and the original light returns; colour swatches/picker; *Custom* with animation; light sound plays only when something changed; reopening the window shows the current light. Without ATL: warning, the light options are greyed, vision still works.
- [ ] **Old torch:** a token with the old SUCC *Torch* effect loses it when a light is applied/removed; toggling *Torch* in the HUD no longer opens Token Vision.
- [ ] Light power / Darksight of the Effect Builder (also ATL) still work next to it. Known limit: if an ATL effect that changes vision is active, ATL restores its remembered original vision values when it ends.

## 3o. SWIM Configuration window (#61)

- [ ] Opens from Module Settings > SWIM > Configure; all former settings are there on their tabs; the search finds settings across all tabs and shows *no results* text for nonsense.
- [ ] Changing a value highlights the row and updates the counter; the per-row reset restores the default; Save is disabled without changes; Cancel/X discards.
- [ ] Select, number (including 0), text, checkbox settings save correctly; file pickers fill the field; the play button previews sound settings.
- [ ] Only changed settings are written. The page does **not** reload on Save; Foundry's reload dialog appears only if one of Condition Roll Mode, SWD Unshake, BR2 support or BR2 Ammo Management changed (marked *Reload needed*).
- [ ] The Ko-fi block at the bottom still shows/links.

## 3p. Combat Setup – window (#63, never tested)
- [ ] **Entry:** the fist icon in the token controls (GM only; needs the Raise Calculator button setting on) and `swim.combat_setup()` open the window. A player gets an error. No tokens / only tokens without actor -> error; everything already in the combat -> info, no window.
- [ ] **List:** sections by disposition, Wild Cards first, chips (Wild Card, Vehicle, Hidden, Defeated). Defeated/Incapacitated NPCs are unticked, characters and vehicles ticked. *All* / *None* per section; preview line and button follow every click.
- [ ] **Grouping:** several Extras of the same actor -> preview shows e.g. "Goblin x4"; Wild Cards, PCs, vehicles never grouped; different disposition or hidden -> separate groups. *Max. distance* 2 with two clusters of Extras far apart -> two groups; 0 -> one. Grouping off -> none.
- [ ] **Add to Combat (no combat yet):** a combat is created and active for the scene, all ticked tokens appear in the Combat Tracker (hidden tokens as hidden combatants). Group leader and followers show as a group in the tracker (leader icon / followers under it). Window switches to the ready view.
- [ ] **Start Combat:** with Automatic Initiative on, cards are drawn by SWADE (player prompts if needed), **one card per group**, followers share the leader's card, combat starts at round 1 with the first combatant. With Automatic Initiative off the *Draw the action cards* box appears: ticked = cards drawn, unticked = none drawn.
- [ ] **Start right away** box: window closes after adding and starting. Changing groups in the tracker (drag onto another combatant) between *Add* and *Start* works.
- [ ] **Existing combat:** open on a scene with a combat (not started): tokens already in it are not listed, new ones are added to it. Running combat: tokens are added, no *Start* button, hint to draw cards. A combat of another scene is never used.
- [ ] **Turn order after starting:** pressing *Next Turn* afterwards does **not** jump back to the first combatant (the old turn-0 hack did).
- [ ] **Combat playlist (setting on):** starting the combat stops other playing playlists (except the protected folder) and plays the *Combat Playlist* setting; ending the combat resumes the others and stops that playlist, also with a playlist name other than "Combat".

## 3q. Scene Illumination in the scene configuration (#64, never tested)
- [ ] **Section:** open a scene's configuration > Lighting tab (GM): a red-framed *SWIM Scene Illumination* section with a SWIM badge sits below the Darkness Level; players never see it. Switching tabs and re-opening keeps it; the window grows to fit.
- [ ] **Preselect:** a scene without the flag shows *Not set*; after the Scene Illumination button (or this section) set a level, that level is highlighted. The highlight follows clicks.
- [ ] **Save:** pick *Dark*, Save -> the Scene Illumination button window shows *Dark*; with Automatic vision adjustments on, tokens of the scene get their vision updated (once). Saving again without a change does nothing to the tokens.
- [ ] **Not set:** with a level stored, pick *Not set*, Save -> flag removed (button window falls back to the darkness-derived level). On a scene that never had a flag, saving with *Not set* stores nothing.
- [ ] The scene configuration of another tab/unrelated fields saves as before (name, grid, darkness).

## 3r. SWID lists in Item Options: vision and potions (#66, never tested; replaces the #65 Token Vision tab)
- [ ] **Translations:** the SWIM Configuration and every SWIM window show texts, not raw keys (#65 broke `en.json`; check the JSON loads).
- [ ] **Item Options tab:** *Vision SWIDs* and *Potion SWIDs* each show an *Edit list* button and an entry count ("3 entries" / "12 entries" by default); search finds them. No Token Vision tab any more.
- [ ] **Editor window:** opens prepopulated (vision: darkvision, infravision, low-light-vision; potions: 6 health + 6 fatigue). *Add entry* adds an empty focused row; the selector sets the type (vision: Darkvision / Infravision / Night Vision Device / Low Light Vision; potions: Health / Fatigue); the trash button removes a row; typed text in other rows survives add/remove. *Apply* writes it back (spaces/case are tidied to a SWID such as `half-elf`, empty rows and duplicates dropped); *Cancel* changes nothing; *Reset to defaults* restores the defaults.
- [ ] **Config window:** after *Apply* the count changes, the row is marked changed and *Save* is enabled; saving stores it; the per-row reset returns to the defaults. Closing the configuration while an editor is open does not throw.
- [ ] **Vision defaults unchanged:** tokens with the old SWID items still get Darkvision / Infravision / Low Light Vision (macro *Automatic* and scene illumination hook).
- [ ] **Custom vision SWID:** add `dwarf` = Low Light Vision, give an actor an item (ancestry) with SWID `dwarf` and no other vision ability -> Token Vision (*Automatic*) shows Low Light Vision "Ability found on the token". Add a SWID as Night Vision Device -> *Automatic* picks it (NVD sound on/off); priority with several matches: Darkvision, Infravision, NVD, Low Light. Emptying the list switches automatic detection off (manual buttons still work).
- [ ] **Amount per potion (#67):** the potion editor has a number column *Per use* (default 1, new rows 1, invalid/0 becomes 1, max 20); the vision editor has none. In the Health Centre (self and on someone else, wounds and fatigue) the selected potion shows its number without + / - buttons, the preview and the result match it (set a potion to 2: heals 2 Wounds / cures 2 Fatigue; with only 1 Wound left it heals 1), changing the potion in the dropdown changes the number. As a player on someone else: a potion with a number is accepted; the socket guard rejects an amount above the configured one. A list saved before #67 (no numbers) counts as 1 each.
- [ ] **Potions in the Health Centre:** with the default list, items named like the old defaults (they have the matching SWID, or none) appear in the health / fatigue potion dropdowns as before. An item renamed to anything but with SWID `health-potion` appears; adding a new SWID with type *Fatigue* makes its item show up in the fatigue dropdown only. Using a potion still works (wounds / fatigue reduced, quantity decreases); as a player the socket guard accepts a listed potion and rejects an unlisted item.
- [ ] **Migration (GM, once):** a world that had custom *Health/Fatigue Potion Names* gets them as SWIDs in the list on the first GM login after the update (names like `Elixir of Life` -> `elixir-of-life`); a world with the old defaults gets the default list. The old settings are hidden and not touched again.

## 3s. Auras / command range (#68, never tested)
Setup: a GM, a commander token (e.g. an Edge item "Command" with an Active Effect that has `system.attributes.spirit.unShakeBonus` ADD 1 and *transfer* on), three friendly Extras (unlinked), one hostile token. Grid: 1 square = 1" (SWADE).
- [ ] **Aura tab (GM):** every Active Effect sheet has an *Aura* tab (red SWIM badge); players do not get it. The tab keeps working after the sheet re-renders (saving while it is open). An effect saved *without* ticking the box gets no `flags.swim.aura` (console: `effect.flags.swim`).
- [ ] **Suppression (most important assumption, `ActiveEffect#isSuppressed` in v11):** with the aura ticked and *Also affects the owner* off, the commander's own Unshake bonus (Unshake window, Bonus block / character sheet) does **not** include the +1. Untick the aura -> the +1 is there. If the commander is affected anyway, tell me: console shows a warning "isSuppressed not found" or the getter is not used by the actor.
- [ ] **Range selector:** *Command range* / *Aura 1* / *Aura 2* / *Custom*; the radius field is only visible for Custom (switching the select shows/hides it at once). Command range: SWIM config of the actor, field *Command range* near the top (default 5); change it to 3 -> the copies on tokens 4+ squares away disappear without touching the aura effect. Aura 1/2: set a different radius for each in SWADE's token config > Auras (enabled or not) -> the effect follows the chosen one; changing it there updates the copies. An Active Effect on the commander that changes `flags.swim.config.commandRange` changes the range too.
- [ ] **Tangent case (user screenshot, 2x2 commander, radius 5):** a 1x1 token whose square only touches the SWADE circle at a corner is NOT affected, whether it got there from inside or from outside. If a copy stays on such a token: run `swim.aura_debug()` in the console (F12) and send the table.
- [ ] **Range = SWADE aura:** on the commander token, enable SWADE's own aura (token config > Auras) with the same radius (e.g. 5) and compare: every Extra the coloured circle touches (even just a corner of its square) gets a copy, every Extra outside does not; straight 5 squares away yes, 6 no, the diagonal (5,5) no. A 2x2 commander measures from its edge. Moving a token in/out of range adds/removes the copy within ~0.2 s (watch the effect list of the Extra's sheet). Radius 1 = the neighbours incl. diagonals.
- [ ] **Disposition:** *Allies* -> friendly Extras only, the hostile token gets nothing; *Enemies* -> only the hostile token; *Everybody* -> all. Changing a token's disposition in its config updates the copies. A neutral token only gets it with *Everybody*.
- [ ] **Name on token:** set *Name on token* = `Under Command` -> the copies carry that name (effect list, Unshake window line); empty -> the name of the source effect; changing it renames the existing copies.
- [ ] **Wild Cards:** *Also affects Wild Cards* off (default) -> a Wild Card (character, or NPC with the Wild Card box) in range gets nothing, Extras do; on -> Wild Cards get the copy too. With *Also affects the owner* ticked the owner gets his copy even if he is a Wild Card.
- [ ] **Also affects the owner:** ticked -> the commander carries a copy (and is affected); unticked -> no copy.
- [ ] **Source inactive:** hide the commander token -> all copies vanish, unhide -> back. Add the Incapacitated condition (or Bleeding Out / Dead) to the commander -> copies vanish, remove it -> back. Disabling the source effect (or the Edge item's effect) or removing the Edge removes the copies.
- [ ] **Edit the source:** change the value of a change / the icon / the name of the source effect -> existing copies are updated (not duplicated). Change the radius -> copies appear/disappear accordingly. Untick *This effect is an aura* -> all copies are removed (the settings stay in the tab).
- [ ] **Two commanders:** both with the same aura and an Extra between them -> exactly one copy (from the nearer one) unless *Stacks* is ticked on both, then two. Moving the Extra switches the copy to the other commander without leaving two.
- [ ] **Unlinked and linked tokens:** Extras that are unlinked tokens (separate synthetic actors) are handled one by one; a linked actor with two tokens on the scene gets one copy. Deleting a token, or dragging a recipient to another scene, leaves no stale copy on a linked actor.
- [ ] **Player view:** a player who owns an Extra sees the copy on the sheet and the bonus applies (Unshake window). The player moving their own token triggers the update (GM client does it); with **no GM connected** nothing changes (no error), and the GM who connects later catches up for the scene he views (or `swim.recalculate_auras()`).
- [ ] **Setting:** SWIM Configuration > Misc > *Aura effects* off -> all copies disappear and the commander is no longer suppressed; on -> back. `swim.recalculate_auras()` as GM shows "Auras of <scene> updated ..."; as a player an error.
- [ ] **Unshake window of a recipient:** shows the copy (`+ 1 Under Command`) once and the total is right; the commander's own window does not list the source effect.
- [ ] **No side effects:** a normal Active Effect (no aura) behaves as before; no console errors while dragging tokens in a big scene; SFX hooks do not play sounds for the copies (unless the copy carries a Shaken/Stunned/... status).

## 3t. Bonus lists counted twice (#68, never tested)
- [ ] **Skeleton case:** an NPC with *Unshake modifier +2* on the actor sheet and the ability **Undead** (no unshake effect on it) -> the Unshake window shows `+ 2 Undead` only, total bonus +2 (before: +4 with an "Other modifier +2").
- [ ] **Edge with its own effect:** Combat Reflexes (Edge item with a transferred effect on `unShakeBonus` +2, effect name arbitrary) -> one line, +2 (before: effect/other +2 and Edge +2). Same for Unstun (`unStunBonus`) and Soak with Iron Jaw (`soakBonus`).
- [ ] **Still right:** an actor with only a sheet value (+1, no Edge) shows `+ 1 Other modifier`; sheet +3 with Combat Reflexes -> `+ 2 Combat Reflexes` and `+ 1 Other modifier`; a gear item with a transferred effect (+1) shows once under its own name; a disabled effect counts nothing; Combat Reflexes without any effect still gives +2.
- [ ] **Setting *Sheet value replaces Edge bonus* (Misc, default on):** on -> Skeleton total +2 and one console warning (`SWIM | Unshake of Skeleton: ...`) each time the window is built; off -> `+ 2 Undead` and `+ 2 Other modifier` (total +4), no warning. Same for Unstun/Soak.
- [ ] **Known limit (rule on):** a sheet value of +2 meant for something else, on an actor that also has the Edge, is taken as the Edge's (total +2, not +4). The Tweaks dialog shows the total of all sources, so this is rare; switch the setting off if it matters.

## 3u. Warrior's Gift grants Combat Edges (#69, never tested)
Setup: a compendium with Edges (e.g. the SWADE core Edges, categories like *Combat*), a caster with the Warrior's Gift power and Seasoned rank (an Edge of each rank helps), two or three other tokens.
- [ ] **Setting:** SWIM Configuration > Item Options > *Edge Compendium* lists every Item compendium; with *none*, Warrior's Gift shows the error "needs an Edge compendium" and nothing is created.
- [ ] **Picker (player):** targets are shown as buttons, the Edges grouped Novice..Legendary and sorted by name, only Edges with *combat* in the category are listed (Background Edges etc. are not). Edges above the caster's rank are greyed out and cannot be picked. Filter works. Cancel keeps the Effect Builder open and creates nothing.
- [ ] **Picker (GM):** greyed-out Edges can be picked, the status line says *GM override*.
- [ ] **Several targets:** after a pick the next target without an Edge is selected; Grant Edges stays disabled until every target has one; clicking an Edge again takes it back; the same Edge can go to two targets.
- [ ] **Result:** each target has the Edge named *Edge (Warrior's Gift)* with the original SWID and data (open the sheet; check an Edge with an own Active Effect, and one with grants/choices) and an effect *Warrior's Gift: Edge* whose description starts with *Granted Edge*. A raise adds *(raise)* to the effect name.
- [ ] **Caster not a target:** the caster gets the maintaining effect, its description lists *Target: Edge* for every target above the power text. **Caster is a target:** own Edge, no extra maintaining effect.
- [ ] **Removal:** delete a target's effect by hand -> only its Edge disappears. Delete the caster's maintaining effect -> all target effects and all granted Edges disappear. Let the duration expire in combat -> the Edge disappears. Works for unlinked tokens too.
- [ ] **Player:** the whole flow as a player (no *SWIM rejected the request* warning). Other powers of the Effect Builder behave as before.
- [ ] **#70 Caster effects:** the maintaining effect AND the caster's own effect (caster is a target) list *Target: Edge* for all targets; the caster's own effect has no power text; effects of other targets still have the Edge line + power text.
- [ ] **#70 Any power (e.g. Protection, Speed, Boost Trait):** the maintaining effect and the caster's own effect (caster is a target) list the targets (*Affects:* + names), no power text; other targets' effects keep the power text.
- [ ] **#70 Raise:** with *Raise* checked before opening the window, `improved-*` Edges of any rank are selectable for a player (not greyed, no *GM override*); other Edges above rank are still locked. Without Raise they are locked again. Works end to end as a player.
- [ ] **#70 Tooltip:** hovering an Edge shows name, requirements and the description with formatting (bold, lists); follows the row, hides on leaving/scrolling/closing; no stray tooltip stays after Grant/Cancel.
- [ ] **#70 Grants:** an Edge with item grants: the granted items appear named *Item (Warrior's Gift)*, items the actor already had are untouched; they vanish with the effect/Edge. (A choice dialog for the GM is expected for Edges with choices.)

## 3v. Free reroll button, selects, auras (#70, never tested)
- [ ] The circle-arrow button (tooltip *Free reroll (no Benny)*) sits left of *Reroll with Benny* in: Natural Healing, Soak (soak roll and Incapacitation Vigor), Unstun, Unshake (failed roll), Radiation Centre, Tester (Test result, Resist). Tester Support (roll below a raise) and Resist with 0 Bennies: the window stays open with the free reroll (no auto-finish). It rerolls without spending a Benny and without Elan; with 0 Bennies Natural Healing/Soak/Vigor still offer it.
- [ ] Where the labelled free reroll exists (Old Ways Oath, Reliable etc.) that one is shown instead of the icon and still works as before.
- [ ] Opened `<select>` lists in SWIM windows (Chrome/Edge): dark background, readable text; Firefox unchanged.
- [ ] Auras (#68) still work after the radius fix (token with a command Edge: allies inside get the effect, moving removes it). If a double-click on a token opens the wrong actor again, run the console diagnostic from PROJECT_SUMMARY #70 (g) and try with SWIM disabled.

## 4. Conditions: Unshake, Unstun, Mark Dead, Fear Table, Tester
- [ ] **Unshake** / **Unstun** on a Shaken/Stunned token: see 3d / 3e (Unshake tested at #48; the old dialogs were tested at #23/#24).
- [ ] Unshake SFX when the Spirit roll fails and a Benny removes Shaken (**known gap, pinned**).
- [ ] SWD Unshake on: Shaken halves Pace exactly **once**, also after reloading the world; off = no Pace change (**tested at #25**).
- [ ] **Mark Dead** (dead overlay, alive again, SFX) (**tested at #23**).
- [ ] **Fear Table**: Adrenaline Surge (+2 all traits/damage shows in rolls, expires), Phobia name/icon, Heart Attack failed Vigor roll (2d6 rounds), Stunned on success (**tested at #7/#8**).
- [ ] **Tester**: see 3g (the old dialogs: support roll as player tested at #17; critical failure branch never tested).
- [ ] Token Vision: see 3n (the SUCC torch was removed in #59); Combat Setup and Backlasher (**not testable by the user, assumed fine**).

## 5. Effect Builder and Common Bond
- [ ] Effect Builder on self and on other targets, Warp Gate disabled; Boost/Lower Trait names ("Boost Trait (Agility)") (**tested at #1/#2/#17**).
- [ ] Preselection of the power from an item action (SWID) and macro variables (token/item) from the compendium macros.
- [ ] Light power (needs Active Token Effects), noPP mode (**tested**), Power Point cost mode (**never tested**, PP backlog).
- [ ] **Common Bond** as player and GM (**tested at #16/#17**; the new window: see 3i).

## 6. Mighty Summoner (GM and player)
- [ ] Normal, raise (+1 max wound), mirror; name "<Summoner>'s <Creature>", disposition copied, unlinked (**tested at #14/#17**).
- [ ] Player **without** *Create Tokens*: persistent error; **with**: pick location → VFX/SFX → token appears, player can control it (**tested at #12–#14**).
- [ ] GM summons with a player-owned summoner selected → the player controls the summon (**tested at #18**).
- [ ] Right-click cancel → nothing happens, no error; maintenance + "Summoned" effects with icons; effect expiry removes the creature (**tested**).
- [ ] Dismiss via the dialog (VFX + SFX) and via deleting the maintenance effect; open sheet of the dismissed summon closes, the summoner's own sheet stays (**tested at #15/#16**).
- [ ] Illusion actor from the compendium can be summoned (never tested by the assistant).
- [ ] Zombie power: duration 1 hour from the chat card with swid `zombie`.
- [ ] Preset list: GM sees all, player only those with at least Limited; no-Power-Points mode lists each skill once (**tested at #28**).

## 7. Shape Changer (GM and player)
- [ ] Change into a preset (normal + raise), revert, change → other form → revert, same form twice, in combat (initiative/flags kept), elevation kept, new token size/scale, VFX/SFX (**tested at #3/#4 as GM**).
- [ ] As **player**: change and revert; without visible presets: persistent error (**tested at #17; the error at #12**).
- [ ] `swim.revert_shape_change(token)` via API.
- [ ] Known limitation: after a GM-triggered change the player must reload (F5) to select the new token.
- [ ] Power Point paths (general pool, per-Arcane-Background pools, change twice, revert) (**never tested, PP backlog**).

## 7b. Actor picker dialog (#42, Summoner + Shape Changer) – never tested
- [ ] Styles load (manifest `styles`): dialog is dark, cards with image / name / chips / rank circle, no console errors.
- [ ] Grouping by rank (Size -4..-1 N, 0 S, 1..2 V, 3..4 H, 5+ L), "Special" group with Mirror Self on top (Summoner), filter box works, empty filter result text.
- [ ] Caster below a creature's rank: row greyed; as **player** not selectable (confirm stays disabled, double-click does nothing); as **GM** selectable, stays greyed, status line says so.
- [ ] No permission (below Limited): creature not listed. Shape Changer without any visible preset: persistent error, no dialog.
- [ ] `ignoreShapeChangeSizeRule` on: nothing greyed in the Shape Changer.
- [ ] Single click selects, header shows the picked creature, double-click confirms, Enter/Space on a focused row selects, close (X) / Cancel does nothing and throws no error.
- [ ] Summoner look (#43): pentagram icon (header and button), link between summoner and creature (Shape Changer keeps arrow + paw), no rank circle, groups = parent folder names sorted A-Z with creatures sorted by name, no Size greying, Mirror Self in "Special" on top.
- [ ] Summoner permissions (#43): player sees only creatures with at least Limited; GM sees all. Mirror Self greyed below Veteran (player can't pick, GM can).
- [ ] Summoner: raise, duration (Power Points mode) and skill (no Power Points mode) arrive correctly; Mirror Self still works; rest as in section 6.
- [ ] Shape Changer: change (normal/raise) and the "Revert form" button work as in section 7.

## 8. Craft Campfire, Radiation Centre, Travel, Chase
- [ ] **Craft Campfire** with and without a selected token, right-click cancel; light/effect created (**tested at #5/#29**).
- [ ] **Radiation Centre**: Geiger sound only for the triggering player, resistance shown with the right sign (negative values no longer "--2", #38), reroll dialog title (**tested at #30**).
- [ ] **Travel Calculator**: see 3h. Journal creation, "update encounter tables" with and without the "[SWIM] Encounter Tables" folder (**tested at #30**).
- [ ] **Chase Setup**: see 3m (card flip sound plays, cards drawn).
- [ ] Smoke test (opens, runs, no console error): Scale Calculator (Falling Damage + Loot-o-Mat: see 3j).

## 9. Ammo Management
- [ ] Reload/fire/auto-fire/empty/silenced sounds, ammo counts (SWIM's own, not SWADE's – use only one of both systems per table).
- [ ] Ammo with an effect JSON: effect name "<name> [<weapon>]", old JSON containing `label` still works (**tested at #28/#29**).

## 10. Players only (GM-relayed macros)
Run every GM-relayed macro as a **player** and watch for the GM warning "SWIM rejected the request …" (**tested at #17, all passed**): Heal Other, Common Bond, Effect Builder, Summoner (+ dismiss), Shape Change + Revert, Craft Campfire, Tester.
- [ ] With **no GM online**: red "No GM is connected" notice, no half-finished state (**tested at #9**).

## 11. Power Point backlog (one pass, in a world with Power Points enabled)
- [ ] Soak with (Un)Holy Warrior power points – drops on the **general** pool (#28).
- [ ] Shape Changer PP paths (#4).
- [ ] Effect Builder with PP cost (#9).
- [ ] Anything else that reads/writes `system.powerPoints.*` (grep at that time).

## 12. Dependencies and manifest
- [ ] Enable SWIM without lib-wrapper, settings-extender and Warp Gate installed: loads without a prompt (**tested at #21**).
- [ ] Module list shows version, SUCC ≥ 3.3.0, socketlib, portal-lib 1.0.7 and Active Token Effects (ATL ≥ 0.7.2, new in #59) as requirements.
- [ ] SWADE token/combat tracker: Hold works natively (SWIM no longer touches it).
